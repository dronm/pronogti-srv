package main

import (
	"context"
	"errors"
	"flag"
	"fmt"
	"log/slog"
	"net/http"
	"os"
	"os/signal"
	"syscall"

	"github.com/dronm/pronogti/internal/config"
	"github.com/dronm/pronogti/internal/httpapi"
	"github.com/dronm/webapp"
	weblogger "github.com/dronm/webapp/logger"
)

var (
	Version   = "dev"
	Commit    = "none"
	BuildDate = "unknown"
)

func main() {
	if err := run(); err != nil {
		slog.Error("pronogti stopped", "error", err)
		os.Exit(1)
	}
}

func run() error {
	configPath := flag.String("config", config.DefaultConfigPath, "path to JSON configuration")
	flag.Parse()
	if *configPath == config.DefaultConfigPath && flag.NArg() > 0 {
		*configPath = flag.Arg(0)
	}
	cfg, err := config.Load(*configPath)
	if err != nil {
		return err
	}
	if err := weblogger.Init(cfg.Debug.LogLevel, cfg.Debug.LogFormat); err != nil {
		return fmt.Errorf("initialize logger: %w", err)
	}
	if cfg.Debug.LogConfig {
		slog.Info("config loaded", "path", *configPath, "http_addr", cfg.HTTP.Addr)
	}
	if err := registerServices(cfg); err != nil {
		return fmt.Errorf("register services: %w", err)
	}
	requestTimeout, err := cfg.RequestTimeout()
	if err != nil {
		return err
	}
	appContext := &webapp.AppContext{DefaultTimeout: requestTimeout}
	middlewares := []webapp.Middleware{
		webapp.RecoverMiddleware(),
		webapp.QueryIDMiddleware(""),
		webapp.RequestLoggerMiddleware(),
		webapp.CORSMiddleware(cfg.CORS.WebappConfig()),
	}
	router := webapp.MustBuildRouter(appContext, httpapi.BuildRoutes(), middlewares...)

	readTimeout, err := cfg.HTTPReadTimeout()
	if err != nil {
		return err
	}
	writeTimeout, err := cfg.HTTPWriteTimeout()
	if err != nil {
		return err
	}
	idleTimeout, err := cfg.HTTPIdleTimeout()
	if err != nil {
		return err
	}
	shutdownTimeout, err := cfg.ShutdownTimeoutDuration()
	if err != nil {
		return err
	}
	server := &http.Server{
		Addr:              cfg.HTTP.Addr,
		Handler:           router,
		ReadHeaderTimeout: readTimeout,
		ReadTimeout:       readTimeout,
		WriteTimeout:      writeTimeout,
		IdleTimeout:       idleTimeout,
	}
	serverErrors := make(chan error, 1)
	go func() {
		slog.Info("pronogti started", "addr", cfg.HTTP.Addr, "version", Version, "commit", Commit, "build_date", BuildDate)
		serverErrors <- server.ListenAndServe()
	}()
	stop, cancel := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer cancel()
	select {
	case err := <-serverErrors:
		if errors.Is(err, http.ErrServerClosed) {
			return nil
		}
		return fmt.Errorf("serve HTTP: %w", err)
	case <-stop.Done():
	}
	shutdownContext, shutdownCancel := context.WithTimeout(context.Background(), shutdownTimeout)
	defer shutdownCancel()
	if err := server.Shutdown(shutdownContext); err != nil {
		_ = server.Close()
		return fmt.Errorf("shutdown HTTP server: %w", err)
	}
	slog.Info("pronogti stopped gracefully")
	return nil
}
