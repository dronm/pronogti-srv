package main

import (
	"net/http"

	"github.com/dronm/pronogti/internal/cache"
	"github.com/dronm/pronogti/internal/config"
	"github.com/dronm/pronogti/internal/httpapi"
	"github.com/dronm/pronogti/internal/services"
)

func registerServices(cfg *config.Config) error {
	clientTimeout, err := cfg.ClientTimeout()
	if err != nil {
		return err
	}
	cacheTTL, err := cfg.CacheTTLDuration()
	if err != nil {
		return err
	}
	client, err := services.NewYClient(
		cfg.YClients,
		false,
		cfg.SaveYClientsToken,
		&http.Client{Timeout: clientTimeout},
	)
	if err != nil {
		return err
	}
	backend := services.NewYClientService(client, cache.New(cacheTTL))
	httpapi.RegisterServices(backend)
	return nil
}
