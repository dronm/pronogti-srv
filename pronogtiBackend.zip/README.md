# Pronogti backend

Go HTTP API for the Pronogti frontend, integrating with YClients for companies, clients, staff, services, goods and unpaid visit drafts. The application uses [webapp](https://github.com/dronm/webapp) and [modelbind](https://github.com/dronm/modelbind).

## Start

Requirements: Go 1.25 or newer, YClients credentials, and the existing customized [goyclients](https://github.com/dronm/goyclients) checkout referenced by `go.mod`.

```sh
cp config.example.json config.json
# Set the YClients credentials in config.json.
make build
./pronogti -config ./config.json
```

`make run` runs the backend directly from `cmd/pronogti`. `make prod` creates an optimized executable with version metadata.

The local goyclients checkout contains APIs absent from its public revision. It is required for a complete build and test run. See [development](docs/development.md#dependencies) if its location differs.

## Documentation

- [Configuration](docs/configuration.md)
- [API](docs/api.md)
- [Development, Make commands and tests](docs/development.md)

## Layout

| Directory | Contents |
| --- | --- |
| `cmd/pronogti` | Executable entry point and dependency initialization |
| `docs` | Technical documentation |
| `documents` | Business and integration reference materials |
| `internal` | Configuration, HTTP API, models, services, cache and application errors |
| `migrations` | Existing optional PostgreSQL migrations |
| `schema` | Reserved for code generation definitions |

Draft saving remains disabled, and QR payment retains its placeholder response.
