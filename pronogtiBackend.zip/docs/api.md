# API

The API uses root paths and direct JSON objects or arrays. Successful operations return HTTP 200.

| Method | Path | Input / behavior |
| --- | --- | --- |
| GET | `/companies` | Active YClients companies |
| GET | `/{companyID}/client/find/{tel}` | Normalized phone lookup; empty client object if absent |
| GET | `/{companyID}/client/{clientID}/pay-draft` | Latest unpaid visit, goods, services and loyalty balances |
| POST | `/{companyID}/client/register` | Client registration; returns `{"id": ...}` |
| POST | `/{companyID}/client/{clientID}/save-pay-draft` | Saving is disabled; valid input returns `200 null` |
| GET | `/{companyID}/staff` | Active, visible staff |
| GET | `/{companyID}/service-cats` | Optional `staff` filter |
| GET | `/{companyID}/services` | Optional `staff`, `cat`, `term` filters |
| GET | `/{companyID}/goods` | Optional `term` filter |
| POST | `/{companyID}/init-qr-pay` | Placeholder payment response |

Registration accepts JSON and form input. Phone is required; optional email is validated. Birth dates accept `YYYY-MM-DD` and RFC3339 timestamps. Unknown input fields are ignored.

Company and fetched client IDs must be positive integers. Malformed numeric filters return HTTP 400. Lists have no collection-response envelope.

Errors use the standard webapp format:

```json
{
	"error": {
		"code": "bad_request",
		"message": "companyID should be a positive integer"
	}
}
```

Internal errors are logged and sanitized before being returned to clients. The client-not-found public error code is `2000`.

## Disabled and placeholder operations

The draft-saving service call is explicitly commented in `internal/httpapi/services.go`. The underlying implementation remains available, but HTTP requests do not invoke it. The disabled endpoint retains its JSON `null` success response.

QR payment returns payment ID `12345566` and image URL `http://localhost/pronogti/cdn/qr.png`. It does not initialize a real payment.
