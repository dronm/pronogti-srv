# Development

## Dependencies

Use Go 1.25 or newer. webapp and modelbind are pinned to published revisions in `go.mod`.

The application's YClients integration uses additions absent from the public January 2026 goyclients revision, including goods, client filters, visits, loyalty cards and visit updates. Keep the customized local checkout referenced by the replacement in `go.mod`.

To use another local checkout:

```sh
go mod edit -replace=github.com/dronm/goyclients=/path/to/goyclients
go mod tidy
```

A complete build and the full route/domain test suite require that checkout. Focused configuration, cache, request-binding and authentication tests can be checked independently against published dependencies; that does not replace the complete application checks.

## Build and run

```sh
go build -o pronogti ./cmd/pronogti
./pronogti -config ./config.json
```

`config.json` is the default configuration file. The existing positional configuration argument is also accepted:

```sh
./pronogti ./config.json
```

The Makefile resolves paths and its optional `.env` file from the project root, including when invoked with `make -f /path/to/Makefile` from another directory.

| Command | Action |
| --- | --- |
| `make build` | Development build of `./cmd/pronogti`, saved as `./pronogti`; default target |
| `make run` | Run the backend using the root `config.json` |
| `make run CONFIG_FILE=/path/config.json` | Run with another configuration file |
| `make test` / `make test-race` | Run unit tests, optionally with the race detector |
| `make test-integration` | Run `internal/apitest` against `API_BASE_URL`, when that package is present |
| `make prod` | Optimized backend build with version metadata and CGO disabled |
| `make clean` | Remove the backend executable and clear the Go test cache |
| `make codegen [gen\|check\|valid]` | Generate, check or validate schemas when codegen is configured |
| `make migup` / `make migdown` | Apply or revert one migration using `DB_CONN` |
| `make migadd <name>` | Create a migration pair |
| `make migfix <version>` / `make migver` | Force or inspect the migration version |
| `make runsql <name>` | Run a SQL script using `internal/scripts/run_sql.php` |
| `make deploy` / `make deploy-full` / `make deploy-backend` | Run `internal/scripts/deploy.sh --backend-only` |
| `make deploy-no-migrations` | Deploy with `--backend-only --skip-migrations` |

Override build settings on the command line, for example `make prod VERSION=1.0.0` or `make build GO=/path/to/go`.

The project does not currently contain an API integration-test package, codegen configuration/tool declaration, or deployment/SQL helpers. Those targets report missing prerequisites. Add deployment helpers under `internal/scripts/` to use their commands; set `DB_CONN` for database commands. No bot or frontend deployment targets are included.

## Tests

Tests use fake dependencies and HTTP responses rather than the live YClients API.

```sh
go test ./...
go test -race ./...
```

The suite covers configuration/token persistence, cache lifetime and company isolation, authentication concurrency, routing, request validation, the disabled save endpoint, and the dormant save-lock regression.

## Runtime design

Startup and dependency initialization live in `cmd/pronogti`. Middleware and routing use webapp directly; CORS settings are passed through `cfg.CORS.WebappConfig()`.

The YClients connection and in-memory cache are injected into the service. Authentication refreshes are coalesced. Separate synchronization protects authentication state and serialized API calls. Request contexts reach authentication and all subsequent outbound calls; canceling one waiter does not cancel another request's authentication.

Staff and client-phone cache keys include the company ID. Successful client changes invalidate that company's cached phone lookups.

Client lookup and pay-draft URLs share one typed GET dispatch route because their original wildcard patterns overlap under Go's ServeMux rules. The public URLs are unchanged. Client values are encoded through pointers so goyclients date marshalers run for cache entries and HTTP responses.

The backend does not initialize a local database, Redis sessions, permissions, WebSockets or background workers. Existing PostgreSQL migrations are retained for later use.
