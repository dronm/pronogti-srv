# Configuration

The application reads `config.json` by default. Pass `-config /path/config.json` to select another file. `config.example.json` contains placeholder YClients credentials.

Configuration follows the same nested HTTP, CORS and debug structure as Meatshop. Durations use Go duration strings such as `10s` and `3h`.

| Setting | Meaning / default |
| --- | --- |
| `http.addr` | Listen address; `127.0.0.1:59000` |
| `http.read_timeout` | Read/header timeout; `15s` |
| `http.write_timeout` | Write timeout; request deadline plus `5s` |
| `http.idle_timeout` | Keep-alive idle timeout; `60s` |
| `http.request_timeout` | Request-context deadline; `5s` |
| `cors.allowed_origins` | Explicit frontend origins; default `["http://localhost:3000"]` |
| `cors.allowed_methods` | Allowed methods; GET, POST, PATCH, PUT, DELETE and OPTIONS |
| `cors.allowed_headers` | Allowed request headers; Content-Type, Authorization and Query-Id |
| `cors.exposed_headers` | Browser-visible response headers; Query-Id |
| `cors.allow_credentials` | Allow credentials; `true` |
| `cors.max_age_seconds` | Preflight cache lifetime; `86400` |
| `debug.log_config` | Log selected startup configuration fields; `false` |
| `debug.log_level` | `debug`, `info`, `warn` or `error`; default `info` |
| `debug.log_format` | `text` or `json`; default `text` |
| `yClients.partnerToken` | Required YClients partner token |
| `yClients.login` / `yClients.password` | Required YClients credentials |
| `yClients.UserToken` / `yClients.authedAt` | Optional cached authorization token and timestamp |
| `cache.ttl` | In-memory cache lifetime; `3h` |
| `client_timeout` | Timeout for each outbound YClients HTTP request; `10s` |
| `shutdown_timeout` | Graceful shutdown timeout; `10s` |

Origins must contain a scheme and host, for example `https://example.org`; URL paths belong outside CORS origin values. HTTP routing passes these settings directly to webapp's CORS middleware.

Refreshed YClients tokens and timestamps are written atomically to the same configuration file. The resulting file has owner-only permissions, and the configuration directory must be writable by the process.

Logging uses `slog` through `webapp/logger`. Raw goyclients HTTP debug logging remains disabled. Internal errors are logged and sanitized by webapp.

The loader also accepts the previous flat configuration keys and converts them to the nested format when persisting configuration. New configuration files should use the nested fields above. The existing YClients credential key names are preserved.
