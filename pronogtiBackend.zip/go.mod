module github.com/dronm/pronogti

go 1.25.0

require (
	github.com/dronm/goyclients v0.0.0-20260114113417-d78b12de7dd5
	github.com/dronm/modelbind v0.0.0-20261029092949-96c71e56f70f
	github.com/dronm/webapp v0.0.0-20261029093221-bf472cb24144
)

require (
	github.com/dronm/ds/v4 v4.0.0-20260612024620-1d1425e7a834 // indirect
	github.com/dronm/session v0.0.0-20251220011348-444cd0bd6dad // indirect
	github.com/jackc/pgpassfile v1.0.0 // indirect
	github.com/jackc/pgservicefile v0.0.0-20240606120523-5a60cdf6a761 // indirect
	github.com/jackc/pgx/v5 v5.9.2 // indirect
	golang.org/x/text v0.29.0 // indirect
)

// The existing application uses unpublished additions in this local checkout.
replace github.com/dronm/goyclients => /home/andrey/go/goyclients
