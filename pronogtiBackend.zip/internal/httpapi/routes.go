package httpapi

import "github.com/dronm/webapp"

// BuildRoutes preserves the existing public URLs and successful JSON bodies.
func BuildRoutes() []webapp.Route {
	var routes []webapp.Route
	api := webapp.NewGroup("", &routes)

	api.GET("/companies",
		webapp.WithName("companies.list"),
		webapp.WithService("YClients", "Companies"),
	)
	// ServeMux cannot register the crossing find/{tel} and {clientID}/pay-draft
	// patterns separately. One route keeps both public URLs without ambiguity.
	api.GET("/{companyID}/client/{clientID}/{action}",
		webapp.WithName("client.get"),
		webapp.WithService("YClients", "ClientGet"),
		webapp.WithBinder(clientGetBinder),
	)
	api.POST("/{companyID}/client/register",
		webapp.WithName("client.register"),
		webapp.WithService("YClients", "RegisterClient"),
		webapp.WithBinder(registerClientBinder),
	)
	api.POST("/{companyID}/client/{clientID}/save-pay-draft",
		webapp.WithName("client.savePayDraft"),
		webapp.WithService("YClients", "SavePayDraft"),
		webapp.WithBinder(savePayDraftBinder),
	)
	api.GET("/{companyID}/staff",
		webapp.WithName("staff.list"),
		webapp.WithService("YClients", "Staff"),
		webapp.WithBinder(companyBinder),
	)
	api.GET("/{companyID}/service-cats",
		webapp.WithName("serviceCategories.list"),
		webapp.WithService("YClients", "ServiceCategories"),
		webapp.WithBinder(serviceCategoriesBinder),
	)
	api.GET("/{companyID}/services",
		webapp.WithName("services.list"),
		webapp.WithService("YClients", "Services"),
		webapp.WithBinder(serviceListBinder),
	)
	api.GET("/{companyID}/goods",
		webapp.WithName("goods.list"),
		webapp.WithService("YClients", "Goods"),
		webapp.WithBinder(goodsListBinder),
	)
	api.POST("/{companyID}/init-qr-pay",
		webapp.WithName("payment.initQR"),
		webapp.WithService("YClients", "InitQRPayment"),
		webapp.WithBinder(qrPaymentBinder),
	)

	return routes
}
