package httpapi

import (
	"context"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"

	"github.com/dronm/pronogti/internal/models"
	"github.com/dronm/webapp"
)

// routerProbe keeps route registration and binding checks independent of the
// optional goods/visit APIs in the customized goyclients dependency.
type routerProbe struct {
	method string
	input  any
}

func (s *routerProbe) Companies(context.Context) ([]any, error) {
	s.method = "companies"
	return []any{}, nil
}

func (s *routerProbe) ClientGet(_ context.Context, input clientGetRequest) (any, error) {
	s.method, s.input = "clientGet", input
	return input, nil
}

func (s *routerProbe) Staff(_ context.Context, input companyRequest) ([]any, error) {
	s.method, s.input = "staff", input
	return []any{}, nil
}

func (s *routerProbe) SavePayDraft(_ context.Context, input savePayDraftRequest) (*models.PayDraft, error) {
	s.method, s.input = "savePayDraft", input
	return nil, nil
}

func TestProductionRoutesRegisterWithoutAmbiguity(t *testing.T) {
	for _, test := range []struct {
		name          string
		method        string
		path          string
		body          string
		status        int
		serviceMethod string
		action        clientGetAction
		companyID     int64
		clientID      int64
		phone         string
	}{
		{name: "companies", method: http.MethodGet, path: "/companies", status: 200, serviceMethod: "companies"},
		{name: "phone lookup", method: http.MethodGet, path: "/12/client/find/+7(999)123-45-67", status: 200, serviceMethod: "clientGet", action: clientGetFind, companyID: 12, phone: "79991234567"},
		{name: "phone lookup with query", method: http.MethodGet, path: "/12/client/find/79991234567?ignored=1", status: 200, serviceMethod: "clientGet", action: clientGetFind, companyID: 12, phone: "79991234567"},
		{name: "pay draft", method: http.MethodGet, path: "/12/client/45/pay-draft", status: 200, serviceMethod: "clientGet", action: clientGetPayDraft, companyID: 12, clientID: 45},
		{name: "previous intersection", method: http.MethodGet, path: "/12/client/find/pay-draft", status: 200, serviceMethod: "clientGet", action: clientGetFind, companyID: 12, phone: "paydraft"},
		{name: "head lookup", method: http.MethodHead, path: "/12/client/find/7", status: 200, serviceMethod: "clientGet", action: clientGetFind, companyID: 12, phone: "7"},
		{name: "invalid client", method: http.MethodGet, path: "/12/client/bad/pay-draft", status: 400},
		{name: "invalid company", method: http.MethodGet, path: "/bad/client/find/7", status: 400},
		{name: "unsupported action", method: http.MethodGet, path: "/12/client/45/unsupported", status: 404},
		{name: "unsupported method", method: http.MethodPut, path: "/12/client/45/pay-draft", status: 405},
		{name: "staff", method: http.MethodGet, path: "/12/staff", status: 200, serviceMethod: "staff", companyID: 12},
		{name: "save route", method: http.MethodPost, path: "/12/client/45/save-pay-draft", body: `{"client_id":45,"items":[]}`, status: 200, serviceMethod: "savePayDraft", companyID: 12, clientID: 45},
	} {
		t.Run(test.name, func(t *testing.T) {
			probe := &routerProbe{}
			webapp.MustRegisterService("RouteProbe", &routerProbe{}, func(webapp.ServiceContext) any {
				return probe
			})
			routes := BuildRoutes()
			for index := range routes {
				routes[index].ServiceName = "RouteProbe"
			}
			// This uses every production pattern; a crossing wildcard pattern
			// causes the same startup panic that the previous version produced.
			handler := webapp.MustBuildRouter(&webapp.AppContext{}, routes)
			request := httptest.NewRequest(test.method, test.path, strings.NewReader(test.body))
			if test.body != "" {
				request.Header.Set("Content-Type", "application/json")
			}
			response := httptest.NewRecorder()
			handler.ServeHTTP(response, request)
			if response.Code != test.status {
				t.Fatalf("status=%d, want %d; body=%s", response.Code, test.status, response.Body)
			}
			if probe.method != test.serviceMethod {
				t.Fatalf("service method=%q, want %q", probe.method, test.serviceMethod)
			}
			switch input := probe.input.(type) {
			case clientGetRequest:
				if input.Action != test.action || input.CompanyID != test.companyID || input.ClientID != test.clientID || input.Phone != test.phone {
					t.Fatalf("bound client request=%#v", input)
				}
			case companyRequest:
				if input.CompanyID != test.companyID {
					t.Fatalf("bound company request=%#v", input)
				}
			case savePayDraftRequest:
				if input.CompanyID != test.companyID || input.Draft.ClientID != test.clientID {
					t.Fatalf("bound save request=%#v", input)
				}
			}
		})
	}
}
