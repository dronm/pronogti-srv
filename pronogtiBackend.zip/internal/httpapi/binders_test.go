package httpapi

import (
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
)

func TestRegistrationBinderRequiresPhone(t *testing.T) {
	for _, body := range []string{`{}`, `{"phone":""}`, `{"phone":null}`} {
		r := httptest.NewRequest(http.MethodPost, "/12/client/register", strings.NewReader(body))
		r.Header.Set("Content-Type", "application/json")
		r.SetPathValue("companyID", "12")
		if _, err := registerClientBinder(r); err == nil {
			t.Errorf("accepted registration without a phone: %s", body)
		}
	}
}

func TestRegistrationBinderAcceptsFormsAndExistingJSON(t *testing.T) {
	tests := []struct {
		contentType string
		body        string
	}{
		{contentType: "application/json", body: `{"phone":"79991234567","birth_date":"1990-04-05T00:00:00Z","unknown":"ignored"}`},
		{contentType: "application/x-www-form-urlencoded", body: "phone=79991234567&birth_date=1990-04-05"},
	}
	for _, test := range tests {
		r := httptest.NewRequest(http.MethodPost, "/12/client/register", strings.NewReader(test.body))
		r.Header.Set("Content-Type", test.contentType)
		r.SetPathValue("companyID", "12")
		value, err := registerClientBinder(r)
		if err != nil {
			t.Fatalf("bind %s: %v", test.contentType, err)
		}
		request := value.(registerClientRequest)
		if request.CompanyID != 12 || request.Client.Phone != "79991234567" || request.Client.BirthDate == nil || request.Client.BirthDate.Format("2006-01-02") != "1990-04-05" {
			t.Errorf("decoded request = %#v", request)
		}
	}
}

func TestSaveBinderKeepsDisabledPayloadSemantics(t *testing.T) {
	r := httptest.NewRequest(http.MethodPost, "/12/client/45/save-pay-draft", strings.NewReader(`{"client_id":46,"items":[]}`))
	r.Header.Set("Content-Type", "application/json")
	r.SetPathValue("companyID", "12")
	r.SetPathValue("clientID", "45")
	value, err := savePayDraftBinder(r)
	if err != nil {
		t.Fatal(err)
	}
	request := value.(savePayDraftRequest)
	if request.CompanyID != 12 || request.Draft.ClientID != 46 {
		t.Errorf("disabled payload was changed: %#v", request)
	}
}

func TestOptionalBodiesRejectEmptyJSON(t *testing.T) {
	for _, body := range []string{"", " \n\t"} {
		for name, bind := range map[string]func(*http.Request) (any, error){
			"save draft": savePayDraftBinder,
			"QR payment": qrPaymentBinder,
		} {
			r := httptest.NewRequest(http.MethodPost, "/12/init-qr-pay", strings.NewReader(body))
			r.Header.Set("Content-Type", "application/json; charset=utf-8")
			r.SetPathValue("companyID", "12")
			if _, err := bind(r); err == nil {
				t.Errorf("%s accepted an empty JSON document", name)
			}
		}
	}
}
