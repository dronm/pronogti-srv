package httpapi

import (
	"context"
	"encoding/json"
	"errors"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
	"time"

	"github.com/dronm/goyclients"
	"github.com/dronm/pronogti/internal/models"
	"github.com/dronm/webapp"
)

type fakeBackend struct {
	call         string
	companyID    int64
	clientID     int64
	phone        string
	staffID      *int64
	categoryID   *int64
	term         string
	client       models.NewClient
	clientResult goyclients.Client
	payment      models.InitQRPayment
	err          error
}

func (b *fakeBackend) FetchCompanies(context.Context) ([]*goyclients.Company, error) {
	b.call = "companies"
	return []*goyclients.Company{}, b.err
}

func (b *fakeBackend) FindClientByPhone(_ context.Context, companyID int64, phone string) (goyclients.Client, error) {
	b.call, b.companyID, b.phone = "findClient", companyID, phone
	return b.clientResult, b.err
}

func (b *fakeBackend) FetchPayDraft(_ context.Context, companyID, clientID int64) (models.PayDraft, error) {
	b.call, b.companyID, b.clientID = "payDraft", companyID, clientID
	return models.PayDraft{ClientID: clientID, Items: []models.PayDraftItem{}}, b.err
}

func (b *fakeBackend) SavePayDraft(context.Context, int64, models.PayDraftSaveRequest) (models.PayDraft, error) {
	panic("the disabled save endpoint must never call SavePayDraft")
}

func (b *fakeBackend) AddClient(_ context.Context, companyID int64, client models.NewClient) (models.ClientKey, error) {
	b.call, b.companyID, b.client = "registerClient", companyID, client
	return models.ClientKey{ID: 42}, b.err
}

func (b *fakeBackend) FetchStaffList(_ context.Context, companyID int64) ([]goyclients.Staff, error) {
	b.call, b.companyID = "staff", companyID
	return []goyclients.Staff{}, b.err
}

func (b *fakeBackend) FetchServiceCatList(_ context.Context, companyID int64, staffID *int64) ([]*goyclients.ServiceCategory, error) {
	b.call, b.companyID, b.staffID = "serviceCategories", companyID, staffID
	return []*goyclients.ServiceCategory{}, b.err
}

func (b *fakeBackend) FetchServiceList(_ context.Context, companyID int64, staffID, categoryID *int64, term string) ([]*goyclients.Service, error) {
	b.call, b.companyID, b.staffID, b.categoryID, b.term = "services", companyID, staffID, categoryID, term
	return []*goyclients.Service{}, b.err
}

func (b *fakeBackend) FetchGoodsList(_ context.Context, companyID int64, term string) ([]*goyclients.Good, error) {
	b.call, b.companyID, b.term = "goods", companyID, term
	return []*goyclients.Good{}, b.err
}

func (b *fakeBackend) InitQRPayment(_ context.Context, companyID int64, input models.InitQRPayment) (models.InitQRPaymentResp, error) {
	b.call, b.companyID, b.payment = "qrPayment", companyID, input
	return models.InitQRPaymentResp{PaymentID: "placeholder", QRImageURL: "http://localhost/qr.png"}, b.err
}

func testHandler(backend Backend) http.Handler {
	RegisterServices(backend)
	return webapp.MustBuildRouter(&webapp.AppContext{}, BuildRoutes(), webapp.RecoverMiddleware())
}

func performRequest(handler http.Handler, method, path, contentType, body string) *httptest.ResponseRecorder {
	request := httptest.NewRequest(method, path, strings.NewReader(body))
	if contentType != "" {
		request.Header.Set("Content-Type", contentType)
	}
	response := httptest.NewRecorder()
	handler.ServeHTTP(response, request)
	return response
}

func TestExistingRoutesDispatchAndKeepDirectJSON(t *testing.T) {
	tests := []struct {
		name   string
		method string
		path   string
		body   string
		call   string
		array  bool
	}{
		{name: "companies", method: http.MethodGet, path: "/companies", call: "companies", array: true},
		{name: "find client", method: http.MethodGet, path: "/12/client/find/+7(999)123-45-67", call: "findClient"},
		{name: "pay draft", method: http.MethodGet, path: "/12/client/45/pay-draft", call: "payDraft"},
		{name: "register client", method: http.MethodPost, path: "/12/client/register", body: `{"phone":"79991234567"}`, call: "registerClient"},
		{name: "staff", method: http.MethodGet, path: "/12/staff", call: "staff", array: true},
		{name: "categories", method: http.MethodGet, path: "/12/service-cats?staff=5", call: "serviceCategories", array: true},
		{name: "services", method: http.MethodGet, path: "/12/services?staff=5&cat=6&term=hair", call: "services", array: true},
		{name: "goods", method: http.MethodGet, path: "/12/goods?term=cream", call: "goods", array: true},
		{name: "QR payment", method: http.MethodPost, path: "/12/init-qr-pay", body: `{"amount":125.5,"client_id":45}`, call: "qrPayment"},
	}
	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			backend := &fakeBackend{}
			response := performRequest(testHandler(backend), test.method, test.path, "application/json", test.body)
			if response.Code != http.StatusOK {
				t.Fatalf("status = %d, body = %s", response.Code, response.Body)
			}
			if backend.call != test.call {
				t.Fatalf("called %q, want %q", backend.call, test.call)
			}
			if test.call != "companies" && backend.companyID != 12 {
				t.Errorf("company ID = %d, want 12", backend.companyID)
			}
			if test.array && strings.TrimSpace(response.Body.String()) != "[]" {
				t.Errorf("collection response gained an envelope: %s", response.Body)
			}
			switch test.call {
			case "findClient":
				if backend.phone != "79991234567" {
					t.Errorf("phone = %q", backend.phone)
				}
			case "payDraft":
				var draft models.PayDraft
				if err := json.Unmarshal(response.Body.Bytes(), &draft); err != nil || draft.ClientID != 45 || backend.clientID != 45 {
					t.Errorf("draft response = %s, error = %v", response.Body, err)
				}
			case "registerClient":
				if strings.TrimSpace(response.Body.String()) != `{"id":42}` {
					t.Errorf("registration response = %s", response.Body)
				}
			case "services":
				if backend.staffID == nil || *backend.staffID != 5 || backend.categoryID == nil || *backend.categoryID != 6 || backend.term != "hair" {
					t.Errorf("wrong service filters: %#v", backend)
				}
			case "serviceCategories":
				if backend.staffID == nil || *backend.staffID != 5 {
					t.Errorf("staff filter = %v", backend.staffID)
				}
			case "goods":
				if backend.term != "cream" {
					t.Errorf("term = %q", backend.term)
				}
			case "qrPayment":
				if backend.payment.Amount != 125.5 || backend.payment.ClientID != 45 {
					t.Errorf("payment = %#v", backend.payment)
				}
			}
		})
	}
}

func TestSavePayDraftRemainsDisabled(t *testing.T) {
	backend := &fakeBackend{err: errors.New("backend must not be called")}
	response := performRequest(testHandler(backend), http.MethodPost, "/12/client/45/save-pay-draft", "application/json", `{"client_id":45,"items":[]}`)
	if response.Code != http.StatusOK || strings.TrimSpace(response.Body.String()) != "null" {
		t.Fatalf("disabled save response = %d %s, want 200 null", response.Code, response.Body)
	}
	if backend.call != "" {
		t.Fatalf("disabled save called %q", backend.call)
	}
}

func TestClientLookupPreservesDateJSON(t *testing.T) {
	var client goyclients.Client
	if err := json.Unmarshal([]byte(`{"id":42,"birth_date":"1990-04-05"}`), &client); err != nil {
		t.Fatal(err)
	}
	response := performRequest(testHandler(&fakeBackend{clientResult: client}), http.MethodGet, "/12/client/find/79991234567", "", "")
	if response.Code != http.StatusOK {
		t.Fatalf("status = %d, body = %s", response.Code, response.Body)
	}
	var result struct {
		BirthDate string `json:"birth_date"`
	}
	if err := json.Unmarshal(response.Body.Bytes(), &result); err != nil {
		t.Fatalf("client date did not remain JSON text: %v; body = %s", err, response.Body)
	}
	if result.BirthDate != "1990-04-05" {
		t.Fatalf("birth date = %q, want 1990-04-05", result.BirthDate)
	}
}

func TestRegistrationJSONAndFormDates(t *testing.T) {
	tests := []struct {
		name        string
		contentType string
		body        string
	}{
		{name: "JSON date", contentType: "application/json", body: `{"name":"Anna","phone":"79991234567","email":"anna@example.org","birth_date":"1990-04-05","unknown":"ignored"}`},
		{name: "JSON timestamp", contentType: "application/json", body: `{"name":"Anna","phone":"79991234567","email":"anna@example.org","birth_date":"1990-04-05T00:00:00+05:00"}`},
		{name: "form date", contentType: "application/x-www-form-urlencoded", body: "name=Anna&phone=79991234567&email=anna%40example.org&birth_date=1990-04-05"},
	}
	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			backend := &fakeBackend{}
			response := performRequest(testHandler(backend), http.MethodPost, "/12/client/register", test.contentType, test.body)
			if response.Code != http.StatusOK {
				t.Fatalf("status = %d, body = %s", response.Code, response.Body)
			}
			client := backend.client
			if client.Name == nil || *client.Name != "Anna" || client.Phone != "79991234567" || client.Email == nil || *client.Email != "anna@example.org" {
				t.Errorf("decoded client = %#v", client)
			}
			if client.BirthDate == nil || client.BirthDate.Format(time.DateOnly) != "1990-04-05" {
				t.Errorf("birth date = %v", client.BirthDate)
			}
		})
	}
}

func TestInvalidRequestsDoNotReachBackend(t *testing.T) {
	tests := []struct {
		method string
		path   string
		body   string
	}{
		{method: http.MethodGet, path: "/bad/staff"},
		{method: http.MethodGet, path: "/0/staff"},
		{method: http.MethodGet, path: "/12/client/bad/pay-draft"},
		{method: http.MethodGet, path: "/12/services?staff=nope"},
		{method: http.MethodGet, path: "/12/services?cat=nope"},
		{method: http.MethodPost, path: "/12/client/register", body: `{}`},
		{method: http.MethodPost, path: "/12/client/register", body: `{"phone":""}`},
		{method: http.MethodPost, path: "/12/client/register", body: `{"phone":null}`},
		{method: http.MethodPost, path: "/12/client/register", body: `{"phone":"7","email":"broken"}`},
		{method: http.MethodPost, path: "/12/client/register", body: `{"phone":"7","birth_date":"1990-99-99"}`},
		{method: http.MethodPost, path: "/12/client/45/save-pay-draft", body: `{"items":`},
		{method: http.MethodPost, path: "/12/init-qr-pay", body: `{"amount":"wrong"}`},
	}
	for _, test := range tests {
		t.Run(test.path+test.body, func(t *testing.T) {
			backend := &fakeBackend{}
			response := performRequest(testHandler(backend), test.method, test.path, "application/json", test.body)
			if response.Code != http.StatusBadRequest {
				t.Fatalf("status = %d, body = %s", response.Code, response.Body)
			}
			if backend.call != "" {
				t.Errorf("invalid request called %q", backend.call)
			}
		})
	}
}

func TestUpstreamErrorsUseWebappErrorResponse(t *testing.T) {
	backend := &fakeBackend{err: errors.New("upstream credential should not be exposed")}
	response := performRequest(testHandler(backend), http.MethodGet, "/companies", "", "")
	if response.Code != http.StatusInternalServerError {
		t.Fatalf("status = %d, body = %s", response.Code, response.Body)
	}
	var result webapp.ErrorResponse
	if err := json.Unmarshal(response.Body.Bytes(), &result); err != nil {
		t.Fatal(err)
	}
	if result.Error.Code != "internal_error" || strings.Contains(response.Body.String(), "credential") {
		t.Errorf("unexpected error response = %s", response.Body)
	}
}
