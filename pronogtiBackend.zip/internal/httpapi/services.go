package httpapi

import (
	"context"

	"github.com/dronm/goyclients"
	"github.com/dronm/pronogti/internal/models"
	"github.com/dronm/webapp"
)

// Backend is the YClients functionality used by the HTTP API.
// Keeping the boundary explicit lets HTTP contracts be checked without live calls.
type Backend interface {
	FetchCompanies(context.Context) ([]*goyclients.Company, error)
	FindClientByPhone(context.Context, int64, string) (goyclients.Client, error)
	FetchPayDraft(context.Context, int64, int64) (models.PayDraft, error)
	SavePayDraft(context.Context, int64, models.PayDraftSaveRequest) (models.PayDraft, error)
	AddClient(context.Context, int64, models.NewClient) (models.ClientKey, error)
	FetchStaffList(context.Context, int64) ([]goyclients.Staff, error)
	FetchServiceCatList(context.Context, int64, *int64) ([]*goyclients.ServiceCategory, error)
	FetchServiceList(context.Context, int64, *int64, *int64, string) ([]*goyclients.Service, error)
	FetchGoodsList(context.Context, int64, string) ([]*goyclients.Good, error)
	InitQRPayment(context.Context, int64, models.InitQRPayment) (models.InitQRPaymentResp, error)
}

type service struct {
	backend Backend
}

// RegisterServices registers request-scoped transport adapters around the shared
// application dependencies. It must be called before serving requests.
func RegisterServices(backend Backend) {
	webapp.MustRegisterService("YClients", &service{}, func(_ webapp.ServiceContext) any {
		return &service{backend: backend}
	})
}

func (s *service) Companies(ctx context.Context) ([]*goyclients.Company, error) {
	return s.backend.FetchCompanies(ctx)
}

func (s *service) FindClient(ctx context.Context, input findClientRequest) (*goyclients.Client, error) {
	client, err := s.backend.FindClientByPhone(ctx, input.CompanyID, input.Phone)
	if err != nil {
		return nil, err
	}
	return &client, nil
}

func (s *service) PayDraft(ctx context.Context, input payDraftRequest) (models.PayDraft, error) {
	return s.backend.FetchPayDraft(ctx, input.CompanyID, input.ClientID)
}

func (s *service) ClientGet(ctx context.Context, input clientGetRequest) (any, error) {
	switch input.Action {
	case clientGetFind:
		return s.FindClient(ctx, findClientRequest{CompanyID: input.CompanyID, Phone: input.Phone})
	case clientGetPayDraft:
		return s.backend.FetchPayDraft(ctx, input.CompanyID, input.ClientID)
	default:
		return nil, webapp.NotFound("client endpoint not found", nil)
	}
}

func (s *service) RegisterClient(ctx context.Context, input registerClientRequest) (models.ClientKey, error) {
	return s.backend.AddClient(ctx, input.CompanyID, input.Client)
}

func (s *service) Staff(ctx context.Context, input companyRequest) ([]goyclients.Staff, error) {
	return s.backend.FetchStaffList(ctx, input.CompanyID)
}

func (s *service) ServiceCategories(ctx context.Context, input serviceCategoriesRequest) ([]*goyclients.ServiceCategory, error) {
	return s.backend.FetchServiceCatList(ctx, input.CompanyID, input.StaffID)
}

func (s *service) Services(ctx context.Context, input serviceListRequest) ([]*goyclients.Service, error) {
	return s.backend.FetchServiceList(ctx, input.CompanyID, input.StaffID, input.CategoryID, input.Term)
}

func (s *service) Goods(ctx context.Context, input goodsListRequest) ([]*goyclients.Good, error) {
	return s.backend.FetchGoodsList(ctx, input.CompanyID, input.Term)
}

func (s *service) SavePayDraft(ctx context.Context, input savePayDraftRequest) (*models.PayDraft, error) {
	// Saving is intentionally disabled, matching the existing endpoint.
	// draft, err := s.backend.SavePayDraft(ctx, input.CompanyID, input.Draft)
	// return &draft, err
	// A typed nil preserves the existing JSON null response; an untyped nil would
	// make webapp.WriteJSON emit its default {"ok":true} response.
	return nil, nil
}

func (s *service) InitQRPayment(ctx context.Context, input qrPaymentRequest) (models.InitQRPaymentResp, error) {
	return s.backend.InitQRPayment(ctx, input.CompanyID, input.Payment)
}
