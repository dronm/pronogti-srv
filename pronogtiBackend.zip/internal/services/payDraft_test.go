package services

import (
	"context"
	"net/http"
	"testing"
	"time"

	"github.com/dronm/pronogti/internal/cache"
	"github.com/dronm/pronogti/internal/models"
)

func TestSavePayDraftAuthenticatesBeforeLockingClient(t *testing.T) {
	client := newTestYClient(t, nil, testHTTPClient(func(*http.Request) (*http.Response, error) {
		return authResponse(), nil
	}))
	service := NewYClientService(client, cache.New(time.Hour))
	finished := make(chan error, 1)
	go func() {
		_, err := service.SavePayDraft(context.Background(), 1, models.PayDraftSaveRequest{
			ClientID: 1,
			Items: []models.PayDraftItem{{
				ID:       1,
				ItemKind: models.PayDraftItemKindService,
				Quant:    1,
				Price:    100,
			}},
		})
		finished <- err
	}()
	select {
	case err := <-finished:
		if err == nil || err.Error() != "staff id should be set" {
			t.Fatalf("expected local request validation, got %v", err)
		}
	case <-time.After(time.Second):
		t.Fatal("save draft deadlocked while authenticating")
	}
}
