package services

import (
	"context"

	"github.com/dronm/pronogti/internal/models"
)

func (s *YClientService) InitQRPayment(ctx context.Context, compID int64, data models.InitQRPayment) (models.InitQRPaymentResp, error) {

	return models.InitQRPaymentResp{
		PaymentID:  "12345566",
		QRImageURL: "http://localhost/pronogti/cdn/qr.png",
	}, nil
}
