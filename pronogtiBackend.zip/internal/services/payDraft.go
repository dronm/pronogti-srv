package services

import (
	"context"
	"fmt"
	"math"
	"sort"
	"time"

	"github.com/dronm/goyclients"
	"github.com/dronm/pronogti/internal/models"
)

// FetchPayDraft returns the latest client visit that still has unpaid services/goods,
// plus current loyalty bonus information.
func (s *YClientService) FetchPayDraft(
	ctx context.Context,
	compID,
	clientID int64,
) (models.PayDraft, error) {
	if clientID == 0 {
		return models.PayDraft{}, fmt.Errorf("client id should be set")
	}

	if err := s.yClient.auth(ctx); err != nil {
		return models.PayDraft{}, err
	}

	release, err := s.yClient.lockClient(ctx)
	if err != nil {
		return models.PayDraft{}, err
	}
	defer release()

	now := time.Now()
	from := goyclients.APIDate(now.AddDate(0, 0, -30))
	to := goyclients.APIDate(now.AddDate(0, 0, 1))

	filter := goyclients.ClientVisitFilter{
		ClientID: &clientID,
		From:     &from,
		To:       &to,
		PaymentStatuses: []goyclients.ClientVisitPaymentStatus{
			goyclients.ClientVisitPaymentStatusNotPaid,
			goyclients.ClientVisitPaymentStatusPaidNotFull,
		},
	}

	api := s.yClient.Client.NewClientAPI(compID)

	visits, err := api.GetVisits(filter)
	if err != nil {
		return models.PayDraft{}, err
	}

	loyaltyCards, err := api.GetLoyaltyCards(clientID)
	if err != nil {
		return models.PayDraft{}, err
	}

	base := models.PayDraft{
		ClientID:     clientID,
		Items:        make([]models.PayDraftItem, 0),
		BonusToApply: 0,
		BonusCanPay:  0,
		Total:        0,
	}

	for _, card := range loyaltyCards {
		base.BonusTotal += card.Balance
	}

	base.BonusTotal = roundMoney(base.BonusTotal)
	base.BonusCanPay = base.BonusTotal

	sort.SliceStable(visits.Records, func(i int, j int) bool {
		if visits.Records[i].Date == visits.Records[j].Date {
			return visits.Records[i].ID > visits.Records[j].ID
		}

		return visits.Records[i].Date > visits.Records[j].Date
	})

	for _, rec := range visits.Records {
		candidate := base
		candidate.DraftID = fmt.Sprintf("yclients:%d:%d:%d", clientID, rec.VisitID, rec.ID)
		candidate.VisitID = rec.VisitID
		candidate.RecordID = rec.ID
		candidate.Items = make([]models.PayDraftItem, 0, len(rec.Services))
		candidate.Total = 0
		candidate.BonusToApply = 0
		candidate.BonusCanPay = 0

		for _, service := range rec.Services {
			unpaidAmount := roundMoney(service.CostToPay - service.PaidSum)
			if unpaidAmount <= 0 {
				continue
			}

			item := models.PayDraftItem{
				ID:       service.ID,
				LineID:   0,
				Staff:    staffFromClientVisitStaff(rec.Staff),
				Title:    service.Title,
				ItemKind: models.PayDraftItemKindService,
				Quant:    1,
				Price:    unpaidAmount,
				Amount:   unpaidAmount,
			}

			candidate.Total += item.Amount
			candidate.Items = append(candidate.Items, item)
		}

		for _, goodsTransaction := range visits.GoodsTransactions {
			if goodsTransaction.RecordID != rec.ID {
				continue
			}

			master := goodsTransaction.Staff
			if master.ID == 0 {
				master = staffFromClientVisitStaff(rec.Staff)
			}

			for _, good := range goodsTransaction.Goods {
				unpaidAmount := roundMoney(good.CostToPay - good.PaidSum)
				if unpaidAmount <= 0 {
					continue
				}

				quant := good.Amount
				if quant <= 0 {
					quant = 1
				}

				price := roundMoney(unpaidAmount / quant)

				item := models.PayDraftItem{
					ID:       good.ID,
					LineID:   goodsTransaction.ID,
					Staff:    master,
					Title:    good.Title,
					ItemKind: models.PayDraftItemKindGood,
					Quant:    quant,
					Price:    price,
					Amount:   unpaidAmount,
				}

				candidate.Total += item.Amount
				candidate.Items = append(candidate.Items, item)
			}
		}

		candidate.Total = roundMoney(candidate.Total)
		candidate.BonusTotal = base.BonusTotal
		candidate.BonusToApply = 0

		if len(candidate.Items) > 0 {
			return candidate, nil
		}
	}

	return base, nil
}

func (s *YClientService) SavePayDraft(
	ctx context.Context,
	compID int64,
	req models.PayDraftSaveRequest,
) (models.PayDraft, error) {
	if req.ClientID == 0 {
		return models.PayDraft{}, fmt.Errorf("client id should be set")
	}

	if len(req.Items) == 0 {
		return models.PayDraft{}, fmt.Errorf("pay draft items should not be empty")
	}

	if !payDraftHasService(req.Items) {
		return models.PayDraft{}, fmt.Errorf("at least one service item should remain in YClients record")
	}
	if err := s.yClient.auth(ctx); err != nil {
		return models.PayDraft{}, err
	}

	err := func() error {
		release, err := s.yClient.lockClient(ctx)
		if err != nil {
			return err
		}
		defer release()

		if req.VisitID == 0 || req.RecordID == 0 {
			return s.createPayDraftRecordLocked(compID, req)
		}

		return s.updatePayDraftVisitLocked(compID, req)
	}()
	if err != nil {
		return models.PayDraft{}, err
	}

	return s.FetchPayDraft(ctx, compID, req.ClientID)
}

func (s *YClientService) updatePayDraftVisitLocked(compID int64, req models.PayDraftSaveRequest) error {
	if req.VisitID == 0 {
		return fmt.Errorf("visit id should be set")
	}

	if req.RecordID == 0 {
		return fmt.Errorf("record id should be set")
	}

	items, err := buildUpdateVisitItems(req)
	if err != nil {
		return err
	}

	api := s.yClient.Client.NewVisitAPI(compID)
	_, err = api.Update(req.VisitID, req.RecordID, goyclients.UpdateVisit{
		Items: items,
	})
	if err != nil {
		return fmt.Errorf("update YClients visit: %w", err)
	}

	return nil
}

func (s *YClientService) createPayDraftRecordLocked(compID int64, req models.PayDraftSaveRequest) error {
	if req.StaffID == 0 {
		return fmt.Errorf("staff id should be set")
	}

	emptyTime := time.Time{}
	if req.DateTime == emptyTime {
		req.DateTime = time.Now()
	}

	if req.SeanceLength == 0 {
		return fmt.Errorf("seance length should be set")
	}

	if req.Client.Phone == "" {
		return fmt.Errorf("client phone should be set")
	}

	services := make([]goyclients.CreateRecordService, 0)

	for _, item := range req.Items {
		if item.ItemKind != models.PayDraftItemKindService {
			continue
		}

		if item.ID == 0 {
			return fmt.Errorf("service id should be set")
		}

		price, total, err := normalizeDraftMoney(item)
		if err != nil {
			return fmt.Errorf("service %d: %w", item.ID, err)
		}

		services = append(services, goyclients.CreateRecordService{
			ID:        item.ID,
			FirstCost: price,
			Cost:      total,
		})
	}

	if len(services) == 0 {
		return fmt.Errorf("can not create YClients record without services")
	}

	recordAPI := s.yClient.Client.NewRecordAPI(compID)

	created, err := recordAPI.Create(goyclients.CreateRecord{
		StaffID:  req.StaffID,
		Services: services,
		Client: &goyclients.CreateRecordClient{
			Phone: req.Client.Phone,
			Name:  req.Client.Name,
			Email: req.Client.Email,
		},
		DateTime:     goyclients.APIDate(req.DateTime),
		SeanceLength: req.SeanceLength,
		SaveIfBusy:   false,
	})
	if err != nil {
		return fmt.Errorf("create YClients record: %w", err)
	}

	if len(created) == 0 || created[0] == nil {
		return fmt.Errorf("YClients returned no created record")
	}

	createdRecord := created[0]

	req.RecordID = int64(createdRecord.ID)
	req.VisitID = int64(createdRecord.VisitID)

	if payDraftHasGoods(req.Items) {
		if err := s.updatePayDraftVisitLocked(compID, req); err != nil {
			return fmt.Errorf("add goods to created YClients visit: %w", err)
		}
	}

	return nil
}

func buildUpdateVisitItems(req models.PayDraftSaveRequest) ([]goyclients.UpdateVisitItem, error) {
	items := make([]goyclients.UpdateVisitItem, 0, len(req.Items))

	for _, item := range req.Items {
		if item.ID == 0 {
			return nil, fmt.Errorf("item id should be set")
		}

		if item.Quant <= 0 {
			return nil, fmt.Errorf("item %d quantity should be greater than zero", item.ID)
		}

		price, total, err := normalizeDraftMoney(item)
		if err != nil {
			return nil, fmt.Errorf("item %d: %w", item.ID, err)
		}

		masterID := item.Staff.ID
		if masterID == 0 {
			masterID = req.StaffID
		}

		if masterID == 0 {
			return nil, fmt.Errorf("item %d master id should be set", item.ID)
		}

		switch item.ItemKind {
		case models.PayDraftItemKindService:
			items = append(items, goyclients.NewUpdateVisitGoodItem(
				req.RecordID,
				item.LineID,
				item.ID,
				masterID,
				item.Title,
				item.Quant,
				price,
				total,
			))
		case models.PayDraftItemKindGood:
			goodItem := goyclients.NewUpdateVisitGoodItem(
				req.RecordID,
				item.LineID,
				item.ID,
				masterID,
				item.Title,
				item.Quant,
				price,
				total,
			)

			items = append(items, goodItem)

		default:
			return nil, fmt.Errorf("unsupported item kind %q", item.ItemKind)
		}
	}

	return items, nil
}

func normalizeDraftMoney(item models.PayDraftItem) (float64, float64, error) {
	price := roundMoney(item.Price)
	total := roundMoney(item.Amount)

	if price <= 0 && total <= 0 {
		return 0, 0, fmt.Errorf("price or amount should be greater than zero")
	}

	if total <= 0 {
		total = roundMoney(price * item.Quant)
	}

	if price <= 0 {
		price = roundMoney(total / item.Quant)
	}

	return price, total, nil
}

func payDraftHasService(items []models.PayDraftItem) bool {
	for _, item := range items {
		if item.ItemKind == models.PayDraftItemKindService {
			return true
		}
	}

	return false
}

func payDraftHasGoods(items []models.PayDraftItem) bool {
	for _, item := range items {
		if item.ItemKind == models.PayDraftItemKindGood {
			return true
		}
	}

	return false
}

func staffFromClientVisitStaff(staff goyclients.ClientVisitStaff) goyclients.Staff {
	res := goyclients.Staff{
		ID:             staff.ID,
		Name:           staff.Name,
		Specialization: staff.Specialization,
		Avatar:         staff.Avatar,
		AvatarBig:      staff.AvatarBig,
	}

	if staff.Position != nil {
		res.Position = *staff.Position
	}

	return res
}

func roundMoney(value float64) float64 {
	return math.Round(value*100) / 100
}

func minMoney(a float64, b float64) float64 {
	if a < b {
		return a
	}

	return b
}
