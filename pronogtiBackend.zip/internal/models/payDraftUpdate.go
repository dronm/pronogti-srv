package models

import "time"

type PayDraftSaveRequest struct {
	ClientID     int64              `json:"client_id"`
	VisitID      int64              `json:"visit_id"`
	RecordID     int64              `json:"record_id"`
	StaffID      int64              `json:"staff_id"`
	Client       PayDraftClientData `json:"client"`
	DateTime     time.Time          `json:"datetime"`
	SeanceLength int64              `json:"seance_length"`
	Items        []PayDraftItem     `json:"items"`
}

type PayDraftClientData struct {
	Phone string `json:"phone"`
	Name  string `json:"name"`
	Email string `json:"email"`
}
