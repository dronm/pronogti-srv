package models

type InitQRPayment struct {
	Amount   float64 `json:"amount"`
	ClientID int64   `json:"client_id"`
}

type InitQRPaymentResp struct {
	PaymentID  string `json:"payment_id"`
	QRImageURL string `json:"qr_image_url"`
}
